# aedes eggs > 2024-07-09 2:12pm
https://universe.roboflow.com/mosquito-eggs/aedes-eggs-mntab

Provided by a Roboflow user
License: CC BY 4.0

